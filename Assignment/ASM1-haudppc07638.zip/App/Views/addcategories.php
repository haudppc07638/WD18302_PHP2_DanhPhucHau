<div class="main-panel" > 
<div class="col-12 grid-margin stretch-card" style="height: 420px;">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Add categories</h4>
            <form class="forms-sample">
                <div class="form-group">
                    <label for="exampleInputName1">Categories name</label>
                    <input type="text" class="form-control" id="exampleInputName1" placeholder="Name">
                </div>
                <button type="submit" class="btn btn-primary me-2">Submit</button>
                <button class="btn btn-light">Cancel</button>
            </form>
        </div>
    </div>
</div>